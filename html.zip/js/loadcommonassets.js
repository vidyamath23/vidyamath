document.write('<link rel="stylesheet" type="text/css" href="stylesheets/common.css">');
   